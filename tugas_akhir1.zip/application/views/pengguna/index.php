<br><br><br><br>
<div id="maincontent" class="ui main container">
	<h1 class="ui header">Beranda</h1>
	<div class="ui stackable grid">
		<div class="nine wide column">
			<div id="regInnkommende" class="ui stacked segment">
				<a class="ui ribbon orange label">Laboratorium</a>
				<div class="ui centered">
					<div class="ui fluid image">
						<img src="<?= base_url('asset/img/foto_lab2.jpg') ?>">
					</div>

				</div>


			</div>


		</div>
		<div class="seven wide column">
			<?php foreach ($lantai as $row) : ?>
				<div class="ui secondary segment">
					<div class="">
						<a style="width: 100%" type="button" class="ui fluid labeled button" tabindex="0" href="<?= base_url('pengguna/lantai/') ?><?= $row['id_lantai'] ?>">
							<div class="ui fluid green button">
								<i class="building icon"></i> <?= $row['nama_lantai'] ?>
							</div>
							<!-- <a class="ui basic green left pointing label">
								1,048
							</a> -->
						</a>

					</div>
				</div>
			<?php endforeach ?>

		</div>
	</div>
</div>